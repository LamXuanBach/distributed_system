## Requierment
- We need to build 2 application
    - Client: Build GUI that connect and send message to server
    - Server: Accept message from client and forward the message to all connected clien

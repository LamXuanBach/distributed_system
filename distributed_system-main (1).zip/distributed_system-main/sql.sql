CREATE TABLE student (
    name VARCHAR(50),
    id VARCHAR(50),
    year VARCHAR(50),
    gender VARCHAR(50)
);

CREATE TABLE book (
    name VARCHAR(50),
    author VARCHAR(50)
);

CREATE TABLE newspaper (
    name VARCHAR(50),
    type VARCHAR(50)
);

CREATE TABLE login (
	username VARCHAR(50),
    password VARCHAR(50)
);

INSERT INTO login (name, password) VALUE ('long', 'long');

select * from newspaper;


## Requierment
- We need to build 2 application
    - Client: a java UI send Object to server
    - Server

### Client
- Create Java UI with 4 input fied
    - Age
    - Name
    - Gender
    - ID
- Put 4 value into the Student Object
- Send the Object to Server

### Server
- Host a server connect with the Database
- Recieve the Student Object from Client
- Store the information in the database

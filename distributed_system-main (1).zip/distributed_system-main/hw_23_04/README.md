## Requierment
- We need to build 2 application
    - Client: Ask the server data in the advertising of csv
    - Server: Containt advertise.csv

### Client
- Can connect to server ask see the data of advertising.csv
- Then can input more data input advertising.csv

### Server
- Has permission to read and write advertising.csv
- Wait a client connect and send back data in advertising.csv to client
- Wait for client input to update advertising.csv
